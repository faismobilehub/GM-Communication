GM COMMUNICATION website — name update

1. Open your GitHub repository in the browser.
2. Open index.html and choose the pencil/Edit option, OR use Add file > Upload files.
3. Upload this index.html to the repository root and replace the existing index.html.
4. Commit changes.
5. Wait a few minutes, then open https://faismobilehub.github.io/GM-Communication/

The page title and visible brand are set to “GM COMMUNICATION”.
Sample prices are examples only; update them to your real prices before publishing.
WhatsApp orders go to 0332-4136250.
